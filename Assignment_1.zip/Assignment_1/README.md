a) this project will use a set of training emails to predict whether or not 
   an email is spam
b) none
c) 
    1. clone the program
    2. have a data directory that follows the same structure as the example 
       in the src directory
    3. compile and run the program
    4. select your data directory or the example one provided 
    5. allow the program to run
    6. observe the results
d) none